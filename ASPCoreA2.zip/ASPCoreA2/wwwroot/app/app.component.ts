﻿import { Component } from '@angular/core'  
@Component({  
    selector: 'app-loader',  
    template: `  
<div>   
<div>  
 <h4>Welcome to ASP.NET Core Using angular 2 in Visual Studio 2017</h4>
</div></div>
`  
})  
export class AppComponent{}  